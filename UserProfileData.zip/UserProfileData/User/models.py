import psycopg2

# Postgreaql connction
connection = psycopg2.connect(user="postgres",
                                  password="1ce12ec005@ash",
                                  host="127.0.0.1",
                                  port="5432",
                                  database="postgres")
cursor = connection.cursor()


def create_db():
    """
    craeting database usertable and password table
    it will create only once in the entire application but we can modify later based on the requiremnt
    :return: None
    """
    quary1 = "create table usertable (user_id serial primary key, name varchar not null, email varchar not null, " \
             "phone varchar not null,address varchar not null)";
    quary2 = "create table passwardtable (user_id serial , salt varchar not null, password_hash varchar not null, " \
             "status varchar not null)";
    #cursor.execute(quary1)
    cursor.execute(quary2)
    connection.commit()


def insert_date(data):
    """
    inserting data to the usertable and passwordtable
    :param data: dictionary which contains user entered data
    :return: None
    """

    name = data['name']
    email = data['email']
    phone = data['phonenumber']
    address = data['address']
    salt = data['salt']
    password_hash = data['password_hash']
    status = data['status']

    user_table_query = "INSERT INTO usertable(name,email,phone,address)VALUES(%s,%s,%s,%s)"
    user_table_data = (name, email, phone, address)
    cursor.execute(user_table_query, user_table_data)
    password_table_query = "INSERT INTO passwardtable(salt,password_hash,status)VALUES(%s,%s,%s)"
    password_table_data = (salt, password_hash, status)
    cursor.execute(password_table_query, password_table_data)
    connection.commit()
    cursor.close()


def retrive_data(emailid):
    """
    verifying the email id its already exist in database or not
    :param emailid: user entered email id
    :return: fetched data
    """
    quary = "select * from usertable where email = %s"
    cursor.execute(quary, (emailid,))

    data = cursor.fetchall()
    connection.commit()
    return data


def login_validate(emailid):
    """
    validating user login emain and password
    :param emailid: user enterd email id
    :param password: user entered password
    :return: fetched data
    """
    quary = "SELECT usertable.user_id, usertable.email,passwardtable.password_hash FROM usertable INNER JOIN passwardtable ON usertable.user_id = passwardtable.user_id where email = %s;"
    cursor.execute(quary,(emailid,))
    result = cursor.fetchone()
    if result:
        data = result[2]
    else:
        data = 'null'
    connection.commit()
    return data





