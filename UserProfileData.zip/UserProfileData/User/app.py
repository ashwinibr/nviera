from os import abort

from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify
from passlib.handlers.sha2_crypt import sha256_crypt
from User.logic import get_random_string
from User.models import insert_date, retrive_data, login_validate

app = Flask(__name__, template_folder='template')


@app.route('/')
def home():
    """
    This defination display home.html which contains login and register link to navigate
    :return:
    """
    return render_template('home.html')


@app.route("/register", methods=['GET','POST'])
def register():
    """
    This defination display register form and validate user entered data
    :return:
    """
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        salt = get_random_string(8)
        password_hash = sha256_crypt.encrypt(str(request.form.get('password'))+salt)
        phonenumber = request.form.get('phone')
        address = request.form.get('address')
        status = 'active'
        data = retrive_data(email)

        if data:
            flash("Email id is already exist","danger")
        else:
            data = {'name':name, 'email':email, 'phonenumber':phonenumber, 'address':address,
                    'salt':salt,'password_hash':password_hash,'status':status}
            insert_date(data)
            flash("you are registered and can login","success")
            return redirect(url_for('login'))

    return render_template('register.html')

@app.route("/login", methods=['GET','POST'])
def login():
    """
    This defination works for login to the user with entered data
    if its not a valid data its move to bad request
    :return:
    """
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        data = login_validate(email)
        if data != 'null':
            if sha256_crypt.verify(password,data):
                flash("login sucsess", "success")
                return jsonify({'login': 'Success'})
        else:
            flash('email and Password does not match', "danger")
            return redirect(url_for("bad_request"))

    return render_template("login.html")

@app.route('/badrequest400')
def bad_request():
    return abort(400)

if __name__ == '__main__':
    app.secret_key='secrete123'
    app.run(debug=True)